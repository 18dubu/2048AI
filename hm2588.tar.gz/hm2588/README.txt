Name: Handong Ma
UNI: hm2588
email: hm2588@columbia.edu

Project Name: 2048AI
Repository Address: https://github.com/18dubu/2048AI.git


Main Algorithm: minimax with alpha-beta pruning
The hurestic function is similar to that of Nicola's: https://github.com/Nicola17/term2048-AI/blob/master/term2048/ia.py

